import neopixel

from src.plugin import PluginManager
from src.plugin import Plugin
from src.theme.Theme import Theme

class LEDController:
    
    def __init__(self, pin, pixelCount, pluginFolder):
        self.pixels: neopixel.NeoPixel = neopixel.NeoPixel(pin, pixelCount, auto_write=False)
        self.pluginManager: PluginManager.PluginManager = PluginManager.PluginManager(pluginFolder)

        
    def runTheme(self, plugin: Plugin.Plugin, theme: Theme):
        self.runThemeWithPattern(plugin, theme.pattern, theme)
        
    def runThemeWithPattern(self, plugin: Plugin.Plugin, pattern: str, theme: Theme):
        plugin.patternManager.get(pattern).pattern(self.pixels, self.pixels.n, theme)
